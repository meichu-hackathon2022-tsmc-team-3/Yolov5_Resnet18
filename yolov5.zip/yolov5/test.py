import os
import sys
from sklearn.metrics import accuracy_score, confusion_matrix, precision_score, recall_score, f1_score
import cv2
from PIL import Image
import numpy as np
import pandas as pd
import torch
from torchvision import transforms
from tqdm import tqdm
from pascal_voc_writer import Writer


print(torch.__version__)


def yoloCutImage(device, model1, model2, test_name_list, test_dir, crop_dir, output_dir):

    print('Start testing...')

    transform = transforms.Compose([
    transforms.Resize([224, 224]),
    transforms.ToTensor()])

    model1.eval()
    with torch.no_grad():

        bar = tqdm(test_name_list)
        for _, name in enumerate(bar):
            
            # test image path
            image_path = os.path.join(test_dir, name)
            
            # 進行物件偵測
            results = model1(image_path)
            
            # return the predictions as a pandas dataframe
            bbox_df = results.pandas().xyxy[0]

            img = cv2.imread(image_path)

            # create pascal voc writer (image_path, width, height)
            #writer = Writer(image_path, len(img[0]), len(img))
            print(name)
            path = os.path.join(output_dir, name.split('.')[0]) + '.txt'
            f = open(path, 'w')

            for bbox_number in range(len(bbox_df)):
            
                # 偵測到的bounding box
                xmin = int(bbox_df['xmin'][bbox_number])
                ymin = int(bbox_df['ymin'][bbox_number])
                xmax = int(bbox_df['xmax'][bbox_number])
                ymax = int(bbox_df['ymax'][bbox_number])
                confidence = str(round(bbox_df['confidence'][bbox_number],2))

                crop_img = []
                crop_img = img[ymin:ymax, xmin:xmax].copy()
                
                # cv2.rectangle(show_img, (xmin, ymin), (xmax, ymax), (0, 255, 0), 2)
                # cv2.putText(show_img, confidence, (xmin-5, ymin-5), cv2.FONT_HERSHEY_DUPLEX,0.8, (0, 255, 0), 2, cv2.LINE_AA)
                
                # crop image path
                crop_name = name.split('.')[0] + '_' + str(bbox_number) + '.png'
                crop_image_path = os.path.join(crop_dir, crop_name)
                # 已經切好的暫存img
                cv2.imwrite(crop_image_path, crop_img)

                ################ 2nd stage #############################
                imga = Image.open(crop_image_path).convert('RGB')
                image_tensor = transform(imga)
                images = image_tensor.unsqueeze(0)
                images = images.to(device)
                outputs = model2(images)     
                _, predicted = torch.max(outputs.data, 1)
                pred = predicted.cpu().numpy()[0]

                # add objects (class, score, xmin, ymin, xmax, ymax)
                if pred == 0:
                    tuple = ('head', '123', str(xmin), str(ymin), str(xmax), str(ymax), '\n')
                    f.write(' '.join(tuple))
                elif pred == 1:
                    tuple = ('helmet', '123', str(xmin), str(ymin), str(xmax), str(ymax), '\n')
                    f.write(' '.join(tuple))

            f.close()


if __name__ == '__main__':

    # test_dir = sys.argv[1]
    # crop_dir = sys.argv[2]
    test_dir = 'train/image'
    crop_dir = 'crop/'
    output_dir = 'output/'

    test_name_list = [s for s in os.listdir(test_dir)]
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    model1 = torch.hub.load('ultralytics/yolov5', 'custom', path='yolov5.pt')
    model2 = torch.load('Resnet18_98199.pt')
    
    yoloCutImage(device, model1, model2, test_name_list, test_dir, crop_dir, output_dir)

    print('Done !')